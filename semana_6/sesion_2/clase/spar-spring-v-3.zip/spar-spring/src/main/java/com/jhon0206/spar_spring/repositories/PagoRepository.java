package com.jhon0206.spar_spring.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jhon0206.spar_spring.entities.Pago;

public interface PagoRepository extends JpaRepository<Pago,Integer>{

}
