package com.jhon0206.spar_spring.controller;

import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jhon0206.spar_spring.entities.Pago;
import com.jhon0206.spar_spring.services.InquilinoService;
import com.jhon0206.spar_spring.services.PagoService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("pagos")
@RequiredArgsConstructor
public class PagoController {

    private final PagoService servicePago;
    private final InquilinoService serviceInquilino;

    @GetMapping
    public String getPagos(Model model) {
        model.addAttribute("pagos", servicePago.getPagos());
        return "pagos/lista";
    }

    @GetMapping("nuevo")
    public String nuevoPagos(Model model) {
        model.addAttribute("pago", new Pago());
        model.addAttribute("inquilinos", serviceInquilino.getInquilinos());
        return "pagos/formulario";
    }

    @PostMapping("procesar")
    public String procesar(@Valid @ModelAttribute Pago pago, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("pago", pago);
            model.addAttribute("inquilinos", serviceInquilino.getInquilinos());
            return "pagos/formulario";
        }
        pago.setFecha(LocalDateTime.now());
        servicePago.savePago(pago);
        return "redirect:/pagos";
    }
}
