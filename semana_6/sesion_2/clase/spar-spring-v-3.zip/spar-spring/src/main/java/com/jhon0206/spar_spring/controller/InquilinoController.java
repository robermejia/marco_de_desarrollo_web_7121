package com.jhon0206.spar_spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jhon0206.spar_spring.entities.Inquilino;
import com.jhon0206.spar_spring.services.InquilinoService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("inquilinos")
@RequiredArgsConstructor
public class InquilinoController {

    private final InquilinoService service;

    @GetMapping
    public String listado(Model model) {
        model.addAttribute("inquilinos", service.getInquilinos());
        return "inquilinos/lista";
    }

    @GetMapping("nuevo")
    public String insertarForm(Model model) {
        model.addAttribute("inquilino", new Inquilino());
        model.addAttribute("operacion", "Agregar");
        return "inquilinos/formulario";
    }

    @GetMapping("editar/{id}")
    public String editarForm(@PathVariable Integer id, Model model) {
        model.addAttribute("inquilino", service.getInquilinoById(id));
        model.addAttribute("operacion", "Editar");
        return "inquilinos/formulario";
    }

    @PostMapping("procesar")
    public String procesar(@Valid @ModelAttribute Inquilino inquilino, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("inquilino", inquilino);
            model.addAttribute("operacion", (inquilino.getId() == null) ? "Agregar" : "Editar");
            return "inquilinos/formulario";
        }
        service.insUpd(inquilino);
        return "redirect:/inquilinos";
    }
}
