package com.jhon0206.spar_spring.entities;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

@Data
@Entity
@Table(name = "inquilinos")
public class Inquilino {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idinquilinos")
    private Integer id;
    @Column(nullable = false, unique = true)
    @NotBlank(message = "DNI requerido")
    @Pattern(regexp = "[\\d]{8}", message = "El DNI debe tener 8 dígitos")
    private String dni;
    @Column(nullable = false)
    @NotBlank(message = "Nombres requeridos")
    private String nombres;
    @Column(nullable = false)
    @NotBlank(message = "Apellido paterno requerido")
    private String paterno;
    @Column(nullable = false)
    @NotBlank(message = "Apellido materno requerido")
    private String materno;
    @Column
    @Email(message = "El correo no tiene el formato correcto")
    private String correo;
    @Column
    private String telefono;
    @Column(nullable = false)
    @NotNull(message = "Ingrese el valor de la deuda")
    @PositiveOrZero(message = "La deuda no puede ser negativa") //@Min(value = 0, message = "La deuda no puede ser negativa")
    private BigDecimal deuda;
    @Column(name = "fecha_ingreso", nullable = false)
    @DateTimeFormat(pattern="yyyy-MM-dd")
    @NotNull(message = "Ingrese el valor de la fecha")
    @PastOrPresent(message = "La fecha de ingreso no puede ser futura")
    private LocalDate fechaIngreso;

}
