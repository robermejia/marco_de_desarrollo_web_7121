package com.jhon0206.spar_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SparSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SparSpringApplication.class, args);
	}

}
