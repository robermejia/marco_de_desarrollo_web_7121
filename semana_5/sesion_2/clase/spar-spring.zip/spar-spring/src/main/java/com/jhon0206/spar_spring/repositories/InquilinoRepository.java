package com.jhon0206.spar_spring.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jhon0206.spar_spring.entities.Inquilino;

public interface InquilinoRepository 
extends JpaRepository<Inquilino,Integer>{

}
