async function fetchInquilinos() {
    const RESPONSE = await fetch(`http://localhost:8080/api/inquilinos`);
    let data = await RESPONSE.json();
    data = JSON.stringify(data);
    data = JSON.parse(data);
    let salida='';
    for (const e of data) {
        salida += `<tr>
                <td>${e.id}</td>
                <td>${e.dni}</td>
                <td>${e.nombres}</td>
                <td>${e.paterno}</td>
                <td>${e.materno}</td>
                <td>${e.correo}</td>
                <td>${e.telefono}</td>
                <td>S/ ${e.deuda}</td>
                <td>${e.fechaIngreso}</td>
              </tr>`;
    }
    document.getElementById('datos').innerHTML = salida;
}